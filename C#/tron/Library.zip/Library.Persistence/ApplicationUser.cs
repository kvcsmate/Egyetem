﻿using Microsoft.AspNetCore.Identity;

namespace Library.Persistence
{
    public class ApplicationUser : IdentityUser
    {
    }
}
