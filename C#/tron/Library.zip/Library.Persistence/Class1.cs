﻿using System;

namespace Library.Persistence
{
    public class Class1
    {
    }
}
