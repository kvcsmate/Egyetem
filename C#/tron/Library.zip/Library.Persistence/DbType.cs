﻿namespace Library.Persistence
{
    public enum DbType
    {
        SqlServer,
        Sqlite
    }
}
