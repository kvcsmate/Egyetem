﻿namespace Library.Web.Models
{
    public enum DbType
    {
        SqlServer,
        Sqlite
    }
}
