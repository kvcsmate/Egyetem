﻿using Microsoft.AspNetCore.Identity;

namespace Library.Web.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
