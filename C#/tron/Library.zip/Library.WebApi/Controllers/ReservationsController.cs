﻿using Library.Persistence;
using Library.Persistence.DTO;
using Library.Persistence.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationsController : ControllerBase
    {
        private readonly ILibraryService _service;

        public ReservationsController(ILibraryService service)
        {
            _service = service;
        }

        // GET: api/Reservations
        [HttpGet("Volume/{volumeId}")]
        public ActionResult<IEnumerable<ReservationDto>> GetReservations(int volumeId)
        {
            try
            {
                return _service.GetReservationsByVolumeId(volumeId).Select(item => (ReservationDto)item).ToList();
                /* .GetVolume(reservationId)
                 .Reservations
                 .Select(item => (ReservationDto)item).ToList();*/
            }
            catch (Exception)
            {
                return NotFound();
            }
        }
        public ActionResult<ReservationDto> GetReservation(int id)
        {
            try
            {
                return (ReservationDto)_service.GetReservation(id);
            }
            catch (InvalidOperationException)
            {
                return NotFound();
            }
        }
        [Authorize]
        [HttpPut("{id}")]
        public IActionResult PutReservation(int id, ReservationDto reservation)
        {
            if (id != reservation.Id)
            {
                return BadRequest();
            }

            if (_service.UpdateReservation((Reservation)reservation))
            {
                return Ok();
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        [Authorize]
        [HttpDelete("{id}")]
        public ActionResult DeleteReservation(int id)
        {
            if (_service.Deletereservation(id))
            {
                return Ok();
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        [Authorize]
        [HttpPost]
        public ActionResult<ReservationDto> PostReservation(ReservationDto reservationDto)
        {
            var reservation = _service.CreateReservation((Reservation)reservationDto);
            if (reservation == null)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            else
            {
                return CreatedAtAction(nameof(GetReservation), new { id = reservation.Id }, (ReservationDto)reservation);
            }


        }
    }
}

