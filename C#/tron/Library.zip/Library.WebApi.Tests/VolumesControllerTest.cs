﻿using Library.Persistence;
using Library.Persistence.DTO;
using Library.Persistence.Services;
using Library.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;

namespace Library.WebApi.Tests
{
    public class VolumesControllerTest:IDisposable
    {
        private readonly LibraryDbContext _context;
        private readonly LibraryService _service;
        private readonly VolumesController _controller;

        public VolumesControllerTest()
        {
            var options = new DbContextOptionsBuilder<LibraryDbContext>()
                .UseInMemoryDatabase("TestDb")
                .Options;
            _context = new LibraryDbContext(options);
            _service = new LibraryService(_context);
            _controller = new VolumesController(_service);
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }

        [Fact]
        public void GetVolumesTest()
        {
            // Act
            var result = _controller.GetVolumes(1);

            // Assert
            var content = Assert.IsAssignableFrom<IEnumerable<BookDto>>(result.Value);
            Assert.Equal(3, content.Count());
        }

        [Theory]
        [InlineData(11)]
        [InlineData(22)]
        [InlineData(33)]
        public void GetBookByIdTest(int id)
        {
            // Act
            var result = _controller.GetVolume(id);

            // Assert
            var content = Assert.IsAssignableFrom<BookDto>(result.Value);
            Assert.Equal(id, content.Id);
        }

        [Fact]
        public void GetInvalidBookTest()
        {
            // Arrange
            var id = 5;

            // Act
            var result = _controller.GetVolume(id);

            // Assert
            Assert.IsAssignableFrom<NotFoundResult>(result.Result);
        }

        [Fact]
        public void PostVolumeTest()
        {
            // Arrange
            var newVolume = new VolumeDto {};
            var count = _context.Volumes.Count();

            // Act
            var result = _controller.PostVolume(newVolume);

            // Assert
            var objectResult = Assert.IsAssignableFrom<CreatedAtActionResult>(result.Result);
            var content = Assert.IsAssignableFrom<BookDto>(objectResult.Value);
            Assert.Equal(count + 1, _context.Books.Count());
        }
    }
}
