﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Library.WebApi.Tests
{
    public class ReservationsControllerTest
    {
    }
}
